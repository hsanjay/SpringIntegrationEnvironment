#!/bin/sh

## FUNCTION TO DISPLAY ERROR AND EXIT
function check_error()
{
    if [ ! "$?" = "0" ]; then
        error_exit "$1";
    fi
}

function error_exit()
{
    echo "${PROGNAME}: ${1:-"Unknown Error"}" 1>&2
    exit 1
}

env > /tmp/env.txt

# Stop the application server. This parameter should point to the script used to stop the application server.
echo "stop the service"
$service_stop

# Ensure that webapps_dir property is assigned to the application server webapps_dir property.
echo "copy the war file ${war_file} to ${webapps_dir}/${context}.war"
cp -f ${war_file} ${webapps_dir}/${context}.war
check_error "Cannot copy the war file to the webapp directory"

# Start the application server. This parameter should point to the script used to start the application server.
echo "start the service"
$service_start

            