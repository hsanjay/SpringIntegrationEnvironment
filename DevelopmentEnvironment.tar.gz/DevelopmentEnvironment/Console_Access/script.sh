trap "APPDEXITSTATUS=\$?;printenv > $2;exit $APPDEXITSTATUS" EXIT
# Execute action script
source $1
APPDRETURNSTATUS=$?
# Unset trap
trap - EXIT
# Save env variables in output properties file
printenv > $2
exit $APPDRETURNSTATUS

