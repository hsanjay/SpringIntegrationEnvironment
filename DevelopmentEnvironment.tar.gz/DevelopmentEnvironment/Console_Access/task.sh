#!/bin/sh

echo $console_password | passwd --stdin root