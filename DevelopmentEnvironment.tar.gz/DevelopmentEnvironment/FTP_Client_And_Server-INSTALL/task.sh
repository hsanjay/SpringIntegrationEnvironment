#!/bin/sh

yum --nogpgcheck -y install curl


if [ $ftp_server = "yes" ]; then
  yum --nogpgcheck -y install vsftpd
fi

yum --nogpgcheck -y install ftp
