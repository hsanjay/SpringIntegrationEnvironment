#!/bin/sh
# vFabric ApplicationDirector CONFIG script for vFabric tc Server

# From ApplicationDirector - Import and source global configuration
. $global_conf

set -e

# Set the computed property values so that they have the values when exposed

export server_node_index=$node_index
export server_node_ip=$node_ip

export PATH=$PATH:/usr/sbin:/sbin:/usr/bin:/bin
export HOME=/root
export tcserver_home=${tcserver_home:="/opt/vmware/vfabric-tc-server-standard"}
export JAVA_HOME=${java_home:="/usr"}
export instance_name=${instance_name:="vfabric-tc-server-sample"}
export node_ip=${node_ip:="10.10.1.1"}

if [ -f ${tcserver_home}/${instance_name} ]; then
    echo "ERROR: The directory ${tcserver_home}/${instance_name} already exists and we will not overwrite it. Exiting script"
    exit 1
fi

# Create instance root directory
mkdir -p $instance_root_dir

DBUSER=""
DBPASS=""
JDBCURL=""
echo "db_username:$db_username"
echo "db_password:$db_password"
template_filename=`basename ${external_template}`
# Download and expand external_template
if [ -f ${external_template} -a ${template_filename##*.} == "tgz" ]; then
    echo "Found external template..."
    pushd .
    cd ${tcserver_home}/templates
    TEMPLS="-t ""`basename ${external_template} | sed 's/\.tgz$//' | sed 's/\.tar.gz$//'`"
    TNAME="`basename ${external_template} | sed 's/\.tgz$//' | sed 's/\.tar.gz$//'`"
    if [ ! $db_username == "" ]; then
        DBUSER="-p${TNAME}.db_username=${db_username}"
    fi
    if [ ! $db_password == "" ]; then
        DBPASS="-p${TNAME}.db_password=${db_password}"
    fi
    if [ "$jdbc_url" != "" ]; then
        JDBCURL="-p${TNAME}.jdbc_url=${jdbc_url}"
    fi
    echo "Using these properties: $PORTS $DBUSER $DBPASS $JDBCURL"
    echo "external template:$external_template"
    tar -zvxf $external_template
    popd
fi

# create a tc Server instance.
if [ -f ${tcserver_home}/tcruntime-instance.sh ]; then
    # construct strings with all templates and ports to supply as an argument to instance create command
    echo "Constucting tc Server command options...."
    for (( i = 0 ; i < ${#templates[@]} ; i++ )); do
        TEMPLS="$TEMPLS"" -t ${templates[$i]}"
        PORTS="$PORTS"" -p${templates[$i]}.http.port=${port}"
    done
    echo "Using these templates: ${TEMPLS}"
    echo "Using these properties: $PORTS $DBUSER $DBPASS $JDBCURL"

    # create new instance under instance_root_dir
    echo "Creating tc Server instance: ${instance_name}, Under directory:  ${instance_root_dir}"
    if [ $use_ajp == "yes" ]; then
        echo "${tcserver_home}/tcruntime-instance.sh create ${instance_name} ${TEMPLS} -t ajp --instance-directory ${instance_root_dir} $PORTS $DBUSER $DBPASS $JDBCURL"
        ${tcserver_home}/tcruntime-instance.sh create ${instance_name} ${TEMPLS} -t ajp --instance-directory ${instance_root_dir} $PORTS $DBUSER $DBPASS $JDBCURL
    else
        echo "${tcserver_home}/tcruntime-instance.sh create ${instance_name} ${TEMPLS} --instance-directory ${instance_root_dir} $PORTS $DBUSER $DBPASS $JDBCURL"
        ${tcserver_home}/tcruntime-instance.sh create ${instance_name} ${TEMPLS} --instance-directory ${instance_root_dir} $PORTS $DBUSER $DBPASS $JDBCURL
    fi
    echo "COMPLETED: A new tc Server instance has been created in ${tcserver_home}/${instance_name}"
    echo "List of templates applied : ${templates[@]}"
else  
    echo "ERROR: tc Server ${version} is been installed in ${tcserver_home}"
    echo "ERROR: please run tc-server installation script first. Exiting CONFIGURE"
    exit 1
fi

export webapps_dir="$instance_dir/webapps"
export service_start="$instance_dir/bin/tcruntime-ctl.sh start"
export service_stop="$instance_dir/bin/tcruntime-ctl.sh stop"
export service_restart="$instance_dir/bin/tcruntime-ctl.sh restart"


# Add the jvmRoute attr to the Engine 
if [ -f $instance_dir/conf/server.xml -a ${has_jvm_route} == "yes" ]; then
    echo "Setting jvmRoute to ${node_index} for sticky session configuration on load balancer"
    sed -ie "s/\(Engine defaultHost=\"localhost\"\)$/\1 jvmRoute=\"${node_index}\"/" ${instance_dir}/conf/server.xml 
fi

# Add Database IP to catalina.properties
if [ ! $db_ip == "" ]; then
    echo "Setting Database IP config at catalina.properties"
    echo "" >> ${instance_dir}/conf/catalina.properties
    echo "db_ip=${db_ip}" >> ${instance_dir}/conf/catalina.properties
fi

# Add Database Port to catalina.properties
if [ ! $db_port == "" ]; then
    echo "Setting Database Port config at catalina.properties"
    echo "" >> ${instance_dir}/conf/catalina.properties
    echo "db_port=${db_port}" >> ${instance_dir}/conf/catalina.properties
fi

# Add jdbc_url to catalina.properties
if [ ! $jdbc_url == "" ]; then
    echo "Setting jdbc_url=${jdbc_url} in catalina.properties"
    echo "" >> ${instance_dir}/conf/catalina.properties
    echo "jdbc_url=${jdbc_url}" >> ${instance_dir}/conf/catalina.properties
fi

# Add NANO_RABBIT_HOST to catalina.properties
if [ ! $rabbitmq_node_ip == "" ]; then
    echo "Setting NANO_RABBIT_HOST config at catalina.properties"
    echo "" >> ${instance_dir}/conf/catalina.properties
    echo "NANO_RABBIT_HOST=${rabbitmq_node_ip}" >> ${instance_dir}/conf/catalina.properties
fi

# Add NANO_RABBIT_PORT to catalina.properties
if [ ! $rabbitmq_node_port == "" ]; then
    echo "Setting NANO_RABBIT_PORT config at catalina.properties"
    echo "" >> ${instance_dir}/conf/catalina.properties
    echo "NANO_RABBIT_PORT=${rabbitmq_node_port}" >> ${instance_dir}/conf/catalina.properties
fi