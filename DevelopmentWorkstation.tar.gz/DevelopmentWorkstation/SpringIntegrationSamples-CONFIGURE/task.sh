#!/bin/bash

# Import global conf 
. $global_conf

set -e

export HOME=/root

env

cd $PROJ_HOME/basic/http

sed -i "s/<\/plugins>/<plugin>\n<groupId>org.codehaus.mojo<\/groupId>\n<artifactId>tomcat-maven-plugin<\/artifactId>\n<configuration>\n<url>http:\/\/$http_host:8080\/manager\/html<\/url>\n<server>\"DevServer\"<\/server>\n<path>\/http<\/path>\n<\/configuration>\n<\/plugin>\n<\/plugins>/g" pom.xml

find `pwd` -name "*.xml" -print | xargs sed -i "s/localhost/$http_host/g"

$M2_HOME/bin/mvn clean package

mv target/http*.war target/http.war

curl -T target/http.war ftp://ftpuser:ftpuser@$http_host