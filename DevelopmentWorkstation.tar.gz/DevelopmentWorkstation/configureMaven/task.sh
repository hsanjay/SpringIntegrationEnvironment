#!/bin/sh

sed -i "s/<\/servers>/<server>\n <id>$server<\/id>\n <username>$tcUsername<\/username>\n <password>$tcPassword<\/password>\n <\/server>\n <\/servers>/g" $M2_HOME/conf/settings.xml